package com.dicoding.submission_01_fundamental.ui.main

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.submission_01_fundamental.data.response.ItemsItem
import com.dicoding.submission_01_fundamental.databinding.ActivityMainBinding
import com.dicoding.submission_01_fundamental.ui.adapter.UserAdapter
import com.dicoding.submission_01_fundamental.ui.viewModel.MainViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private  val viewModel by viewModels<MainViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val layoutManager = LinearLayoutManager(this)
        binding.listUser.layoutManager = layoutManager

        binding.listUser.setHasFixedSize(true)

        viewModel.listUsers.observe(this) {user ->
            setAdapter(user)
        }
        viewModel.isLoading.observe(this) {
            binding.progressBar.isVisible = it
        }



        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener{ _, _, _ ->
                    searchBar.setText(searchView.text)
                    performSearch(searchView.text.toString())
                    searchView.hide()
                    false
                }
        }

    }

    private fun setAdapter(list: List<ItemsItem>) {
        val adapter = UserAdapter()
        adapter.submitList(list)
        binding.listUser.adapter = adapter
    }

    private fun performSearch(query: String) {
        viewModel.searchUser(query)
    }
}