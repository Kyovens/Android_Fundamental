package com.dicoding.submission_01_fundamental.data.retrofit

import com.dicoding.submission_01_fundamental.data.response.DetailUserResponse
import com.dicoding.submission_01_fundamental.data.response.ItemsItem
import com.dicoding.submission_01_fundamental.data.response.SearchUserResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    fun getAllUser(
        @Query("q") username: String
    ): Call<SearchUserResponse>

    @GET("users/{username}")
    fun getDetailUser(
        @Path("username") username: String
    ): Call<DetailUserResponse>

    @GET("users/{username}/followers")
    fun getFollowers(
        @Path("username") username: String
    ): Call<List<ItemsItem>>

    @GET("users/{username}/following")
    fun getFollowing(
        @Path("username") username: String
    ): Call<List<ItemsItem>>
}